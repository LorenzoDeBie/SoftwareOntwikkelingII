﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProxyModel.Pattern
{
    public class CachingProxyFile : IFile
    {
        // Static dictionary containing all cached files
        private static Dictionary<string, IFile> cachedFiles = new Dictionary<string, IFile>();  //Kan ook RealFile bijhouden

        private string filename;
        private IFile file;

        // Protected constructor!!
        internal CachingProxyFile(string filename)
        {
            this.filename = filename;
        }

        public string Content
        {
            get
            {
                if (file == null)
                {
                    // Check if file is already in cache
                    if (!cachedFiles.ContainsKey(filename))
                    {
                        // Read file from disk and add to cache
                        cachedFiles.Add(filename, new RealFile(filename));
                    }
                    file = cachedFiles[filename];
                }
                return file.Content;
            }
        }
    
    }
}
