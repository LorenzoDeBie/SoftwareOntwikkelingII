﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProxyModel.Pattern
{
    public class AuthenticationProxyFile : IFile
    {
        private User user;
        private string filename;
        private IFile file; //onthouden


        public AuthenticationProxyFile(User user, string filename)
        {
            this.user = user;
            this.filename = filename;
        }

        public string Content
        {
            get
            {
                if (filename.StartsWith("."))
                {
                    if (!user.IsAdmin)
                    {
                        throw new FileAccesException("User '" + user.UserName + "' has no access to this file.");
                    }
                }
                if (file == null)
                {
                    file = new CachingProxyFile(filename);
                    // Remark: If no caching is required, initialize a RealFile instead
                    //file = new RealFile(filename);
                }
                return file.Content;
            }
        }
    
    }
}
