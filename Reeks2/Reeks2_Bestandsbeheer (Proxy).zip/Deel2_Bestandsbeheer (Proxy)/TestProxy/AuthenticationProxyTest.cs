﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ProxyModel.Pattern;

namespace TestProxy
{
    /// <summary>
    /// Example unit tests for the Authentication Proxy
    /// </summary>
    [TestClass]
    public class AuthenticationProxyTest
    {
        /// <summary>
        /// Read file twice (with different user), expect same contents.
        /// </summary>
        [TestMethod]
        public void TestReadFile()
        {
            User testuser = new User("test", false);
            IFile file1 = new AuthenticationProxyFile(testuser, "file1.txt");
            User testadmin = new User("admin", true);
            IFile file2 = new AuthenticationProxyFile(testadmin, "file1.txt");
            Assert.AreEqual(file1.Content, file2.Content);
        }

        /// <summary>
        /// Try to open a hidden file as an admin
        /// </summary>
        [TestMethod]
        public void TestAdminAcces()
        {
            User testadmin = new User("admin", true);
            AuthenticationProxyFile file1 = new AuthenticationProxyFile(testadmin, ".file1.txt");
            string content = file1.Content;
        }

        /// <summary>
        /// Try to open a hidden file as a normal user, expect a FileAccessException
        /// </summary>
        [TestMethod]
        [ExpectedException(typeof(FileAccesException))]
        public void TestAdminAccesException()
        {
            User testuser = new User("test", false);
            IFile file1 = new AuthenticationProxyFile(testuser, ".file1.txt");
            string content = file1.Content;
        }
    }
}
